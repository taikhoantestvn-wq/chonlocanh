package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.FilterType
import com.example.data.model.MediaAnalysis
import com.example.data.model.MediaItem
import com.example.data.model.SortType
import com.example.data.repository.MediaRepository
import com.example.data.service.GeminiApiService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class CurationUiState(
    val mediaItems: List<MediaItem> = emptyList(),
    val isLoading: Boolean = false,
    val isAnalyzingAll: Boolean = false,
    val analyzingProgress: Float = 0f,
    val currentAnalyzingName: String = "",
    val filterType: FilterType = FilterType.ALL,
    val sortType: SortType = SortType.AI_SCORE_DESC,
    val activeDetailItem: MediaItem? = null,
    val hasStoragePermission: Boolean = false,
    val statusMessage: String? = null,
    val showApiKeyDialog: Boolean = false,
    val customApiKey: String = "",
    val hasCustomApiKey: Boolean = false,
    val isTestingApiKey: Boolean = false,
    val apiKeyTestResult: Pair<Boolean, String>? = null
) {
    val displayedItems: List<MediaItem>
        get() {
            val filtered = when (filterType) {
                FilterType.ALL -> mediaItems
                FilterType.AI_RECOMMENDED -> mediaItems.filter { it.analysis?.isRecommended == true }
                FilterType.PHOTOS_ONLY -> mediaItems.filter { !it.isVideo }
                FilterType.VIDEOS_ONLY -> mediaItems.filter { it.isVideo }
            }
            return when (sortType) {
                SortType.AI_SCORE_DESC -> filtered.sortedWith(
                    compareByDescending<MediaItem> { it.analysis?.score ?: -1 }
                        .thenByDescending { it.dateAdded }
                )
                SortType.DATE_DESC -> filtered.sortedByDescending { it.dateAdded }
                SortType.DATE_ASC -> filtered.sortedBy { it.dateAdded }
            }
        }

    val selectedItems: List<MediaItem>
        get() = mediaItems.filter { it.isSelected }

    val recommendedCount: Int
        get() = mediaItems.count { it.analysis?.isRecommended == true }

    val analyzedCount: Int
        get() = mediaItems.count { it.analysis != null }
}

class CurationViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = MediaRepository(application)
    private val apiKeyManager = com.example.data.repository.ApiKeyManager(application)
    private val geminiService = GeminiApiService(apiKeyManager)

    private val _uiState = MutableStateFlow(
        CurationUiState(
            customApiKey = apiKeyManager.getCustomApiKey(),
            hasCustomApiKey = apiKeyManager.hasCustomApiKey()
        )
    )
    val uiState: StateFlow<CurationUiState> = _uiState.asStateFlow()

    init {
        loadMedia()
    }

    fun openApiKeyDialog() {
        _uiState.update {
            it.copy(
                showApiKeyDialog = true,
                customApiKey = apiKeyManager.getCustomApiKey(),
                hasCustomApiKey = apiKeyManager.hasCustomApiKey(),
                apiKeyTestResult = null
            )
        }
    }

    fun dismissApiKeyDialog() {
        _uiState.update { it.copy(showApiKeyDialog = false, apiKeyTestResult = null) }
    }

    fun saveCustomApiKey(key: String) {
        apiKeyManager.saveCustomApiKey(key)
        _uiState.update {
            it.copy(
                customApiKey = key.trim(),
                hasCustomApiKey = key.trim().isNotBlank(),
                statusMessage = "Đã lưu Gemini API Key riêng thành công!"
            )
        }
    }

    fun clearCustomApiKey() {
        apiKeyManager.clearCustomApiKey()
        _uiState.update {
            it.copy(
                customApiKey = "",
                hasCustomApiKey = false,
                apiKeyTestResult = null,
                statusMessage = "Đã xóa API Key riêng, chuyển về cấu hình hệ thống."
            )
        }
    }

    fun testCustomApiKey(key: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isTestingApiKey = true, apiKeyTestResult = null) }
            val result = geminiService.testApiKey(key)
            _uiState.update { it.copy(isTestingApiKey = false, apiKeyTestResult = result) }
        }
    }

    fun setPermissionGranted(granted: Boolean) {
        _uiState.update { it.copy(hasStoragePermission = granted) }
        if (granted) {
            loadMedia()
        }
    }

    fun loadMedia() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val items = repository.loadDeviceMedia()
            _uiState.update { it.copy(mediaItems = items, isLoading = false) }
        }
    }

    fun addPickedUris(uris: List<Uri>) {
        viewModelScope.launch {
            val newItems = uris.map { repository.createItemFromUri(it) }
            _uiState.update { current ->
                val combined = (newItems + current.mediaItems).distinctBy { it.uri }
                current.copy(mediaItems = combined)
            }
            // Automatically analyze newly added items
            analyzeBatch(newItems)
        }
    }

    fun toggleItemSelection(id: Long) {
        _uiState.update { state ->
            val updated = state.mediaItems.map {
                if (it.id == id) it.copy(isSelected = !it.isSelected) else it
            }
            state.copy(mediaItems = updated)
        }
    }

    fun selectAllRecommended() {
        _uiState.update { state ->
            val updated = state.mediaItems.map {
                val isRec = it.analysis?.isRecommended == true
                it.copy(isSelected = isRec)
            }
            state.copy(
                mediaItems = updated,
                statusMessage = "Đã chọn tất cả ${state.recommendedCount} ảnh/video chất lượng cao nhất!"
            )
        }
    }

    fun clearAllSelections() {
        _uiState.update { state ->
            val updated = state.mediaItems.map { it.copy(isSelected = false) }
            state.copy(mediaItems = updated)
        }
    }

    fun setFilter(filter: FilterType) {
        _uiState.update { it.copy(filterType = filter) }
    }

    fun setSort(sort: SortType) {
        _uiState.update { it.copy(sortType = sort) }
    }

    fun openDetail(item: MediaItem) {
        _uiState.update { it.copy(activeDetailItem = item) }
        // If not analyzed, trigger analysis
        if (item.analysis == null && !item.isAnalyzing) {
            analyzeSingleItem(item)
        }
    }

    fun closeDetail() {
        _uiState.update { it.copy(activeDetailItem = null) }
    }

    fun dismissStatusMessage() {
        _uiState.update { it.copy(statusMessage = null) }
    }

    fun analyzeSingleItem(item: MediaItem) {
        viewModelScope.launch {
            setItemAnalyzing(item.id, true)
            val bitmap = repository.loadBitmapForAnalysis(item)
            if (bitmap != null) {
                val analysis = geminiService.analyzeMedia(bitmap, item.isVideo, item.name)
                setItemAnalysis(item.id, analysis)
            } else {
                setItemAnalyzing(item.id, false)
            }
        }
    }

    fun analyzeAllUnanalyzed() {
        val unanalyzed = _uiState.value.mediaItems.filter { it.analysis == null }
        if (unanalyzed.isEmpty()) {
            _uiState.update { it.copy(statusMessage = "Tất cả ảnh và video đã được phân tích!") }
            return
        }
        analyzeBatch(unanalyzed)
    }

    private fun analyzeBatch(items: List<MediaItem>) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isAnalyzingAll = true,
                    analyzingProgress = 0f,
                    currentAnalyzingName = "Bắt đầu chọn lọc AI..."
                )
            }

            items.forEachIndexed { index, item ->
                _uiState.update {
                    it.copy(
                        analyzingProgress = (index + 1).toFloat() / items.size,
                        currentAnalyzingName = "Đang đánh giá: ${item.name} (${index + 1}/${items.size})"
                    )
                }
                setItemAnalyzing(item.id, true)
                val bitmap = repository.loadBitmapForAnalysis(item)
                if (bitmap != null) {
                    val analysis = geminiService.analyzeMedia(bitmap, item.isVideo, item.name)
                    setItemAnalysis(item.id, analysis)
                } else {
                    setItemAnalyzing(item.id, false)
                }
            }

            _uiState.update {
                it.copy(
                    isAnalyzingAll = false,
                    analyzingProgress = 1f,
                    currentAnalyzingName = "",
                    statusMessage = "AI đã hoàn tất chọn lọc! Tìm thấy ${it.recommendedCount} mục chất lượng tốt nhất."
                )
            }
        }
    }

    private fun setItemAnalyzing(id: Long, isAnalyzing: Boolean) {
        _uiState.update { state ->
            val updated = state.mediaItems.map {
                if (it.id == id) it.copy(isAnalyzing = isAnalyzing) else it
            }
            val active = if (state.activeDetailItem?.id == id) {
                state.activeDetailItem.copy(isAnalyzing = isAnalyzing)
            } else {
                state.activeDetailItem
            }
            state.copy(mediaItems = updated, activeDetailItem = active)
        }
    }

    private fun setItemAnalysis(id: Long, analysis: MediaAnalysis) {
        _uiState.update { state ->
            val updated = state.mediaItems.map {
                if (it.id == id) it.copy(analysis = analysis, isAnalyzing = false) else it
            }
            val active = if (state.activeDetailItem?.id == id) {
                state.activeDetailItem.copy(analysis = analysis, isAnalyzing = false)
            } else {
                state.activeDetailItem
            }
            state.copy(mediaItems = updated, activeDetailItem = active)
        }
    }
}
