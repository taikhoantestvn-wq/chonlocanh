package com.example.util

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import com.example.data.model.MediaItem
import java.util.ArrayList

enum class SocialApp(
    val title: String,
    val packageName: String,
    val iconEmoji: String
) {
    ZALO("Zalo", "com.zing.zalo", "💬"),
    MESSENGER("Messenger", "com.facebook.orca", "⚡"),
    FACEBOOK("Facebook", "com.facebook.katana", "🌐"),
    SYSTEM("Ứng dụng khác", "", "📤")
}

object ShareHelper {

    fun isAppInstalled(context: Context, packageName: String): Boolean {
        if (packageName.isBlank()) return true
        return try {
            context.packageManager.getPackageInfo(packageName, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    fun shareItems(
        context: Context,
        items: List<MediaItem>,
        app: SocialApp = SocialApp.SYSTEM,
        caption: String? = null
    ) {
        if (items.isEmpty()) {
            Toast.makeText(context, "Chưa chọn ảnh hoặc video nào để chia sẻ!", Toast.LENGTH_SHORT).show()
            return
        }

        val shareText = buildString {
            if (!caption.isNullOrBlank()) {
                append(caption)
            } else {
                val bestItem = items.maxByOrNull { it.analysis?.score ?: 0 }
                if (bestItem?.analysis != null) {
                    append(bestItem.analysis.suggestedCaption)
                } else {
                    append("Khoảnh khắc đẹp được chọn lọc bởi AI! ✨📸")
                }
            }
        }

        // Copy caption to clipboard so user can easily paste if the target app ignores EXTRA_TEXT
        try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("AI Caption", shareText)
            clipboard.setPrimaryClip(clip)
        } catch (ignored: Exception) {}

        val uris = ArrayList<Uri>(items.map { it.uri })
        val hasImages = items.any { !it.isVideo }
        val hasVideos = items.any { it.isVideo }
        val mimeType = when {
            hasImages && !hasVideos -> "image/*"
            !hasImages && hasVideos -> "video/*"
            else -> "*/*"
        }

        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uris.first())
                putExtra(Intent.EXTRA_TEXT, shareText)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = mimeType
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                putExtra(Intent.EXTRA_TEXT, shareText)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }

        if (app != SocialApp.SYSTEM && app.packageName.isNotEmpty()) {
            if (isAppInstalled(context, app.packageName)) {
                intent.setPackage(app.packageName)
                try {
                    context.startActivity(intent)
                    Toast.makeText(context, "Đang mở ${app.title} (Đã sao chép caption AI)", Toast.LENGTH_SHORT).show()
                    return
                } catch (e: Exception) {
                    // Fallback to chooser
                }
            } else {
                Toast.makeText(
                    context,
                    "${app.title} chưa được cài đặt, mở danh sách ứng dụng chia sẻ...",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        val chooser = Intent.createChooser(intent, "Chia sẻ qua Zalo, Messenger, Facebook...").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(chooser)
        } catch (e: Exception) {
            Toast.makeText(context, "Không tìm thấy ứng dụng hỗ trợ chia sẻ.", Toast.LENGTH_SHORT).show()
        }
    }
}
