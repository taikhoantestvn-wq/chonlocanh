package com.example.data.service

import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import com.example.data.model.MediaAnalysis
import com.example.data.repository.ApiKeyManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

class GeminiApiService(private val apiKeyManager: ApiKeyManager? = null) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    // Models supported by Gemini API, ordered by priority
    private val candidateModels = listOf(
        "gemini-flash-latest",
        "gemini-3.5-flash",
        "gemini-3.1-flash-lite-preview"
    )

    private fun resolveApiKey(): String {
        val customKey = apiKeyManager?.getEffectiveApiKey()
        if (!customKey.isNullOrBlank()) {
            return customKey
        }
        val buildKey = BuildConfig.GEMINI_API_KEY
        return if (buildKey.isNotBlank() && buildKey != "MY_GEMINI_API_KEY") buildKey else ""
    }

    suspend fun testApiKey(apiKey: String): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val trimmedKey = apiKey.trim()
        if (trimmedKey.isBlank()) {
            return@withContext Pair(false, "Vui lòng nhập API Key!")
        }
        try {
            val testJson = JSONObject().apply {
                val contentsArray = JSONArray()
                val contentObj = JSONObject()
                val partsArray = JSONArray()
                partsArray.put(JSONObject().apply { put("text", "Xin chào") })
                contentObj.put("parts", partsArray)
                contentsArray.put(contentObj)
                put("contents", contentsArray)
            }
            val requestBody = testJson.toString().toRequestBody(jsonMediaType)
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent?key=$trimmedKey"
            val request = Request.Builder().url(url).post(requestBody).build()
            val response = client.newCall(request).execute()

            if (response.isSuccessful) {
                Pair(true, "API Key hợp lệ! Kết nối Gemini AI thành công.")
            } else {
                val code = response.code
                val errBody = response.body?.string() ?: ""
                when (code) {
                    400 -> Pair(false, "API Key không đúng định dạng hoặc không hợp lệ (Mã lỗi 400).")
                    403 -> Pair(false, "API Key bị từ chối truy cập (Mã lỗi 403). Vui lòng kiểm tra quyền hoặc hạn mức.")
                    503 -> Pair(true, "API Key hợp lệ (Máy chủ hiện đang quá tải tạm thời - Mã 503).")
                    else -> Pair(false, "Lỗi kết nối Gemini API (Mã $code): $errBody")
                }
            }
        } catch (e: Exception) {
            Pair(false, "Lỗi mạng khi kiểm tra API Key: ${e.localizedMessage}")
        }
    }

    suspend fun analyzeMedia(
        bitmap: Bitmap,
        isVideo: Boolean,
        fileName: String
    ): MediaAnalysis = withContext(Dispatchers.IO) {
        val apiKey = resolveApiKey()
        if (apiKey.isBlank()) {
            Log.w(TAG, "Gemini API key is not set, using smart local heuristic analysis.")
            return@withContext performSmartHeuristicAnalysis(bitmap, isVideo, fileName)
        }

        try {
            val base64Image = bitmapToBase64(bitmap)
            val prompt = buildAnalysisPrompt(isVideo, fileName)

            val requestJson = JSONObject().apply {
                val contentsArray = JSONArray()
                val contentObj = JSONObject()
                val partsArray = JSONArray()

                // Text instruction
                partsArray.put(JSONObject().apply {
                    put("text", prompt)
                })

                // Multimodal inline image/frame
                partsArray.put(JSONObject().apply {
                    put("inlineData", JSONObject().apply {
                        put("mimeType", "image/jpeg")
                        put("data", base64Image)
                    })
                })

                contentObj.put("parts", partsArray)
                contentsArray.put(contentObj)
                put("contents", contentsArray)

                put("generationConfig", JSONObject().apply {
                    put("responseMimeType", "application/json")
                    put("temperature", 0.4)
                })
            }

            val requestBodyString = requestJson.toString()

            // Try candidate models sequentially if one experiences temporary demand spikes (503/429)
            for (model in candidateModels) {
                try {
                    val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
                    val request = Request.Builder()
                        .url(url)
                        .post(requestBodyString.toRequestBody(jsonMediaType))
                        .build()

                    val response = client.newCall(request).execute()
                    val responseCode = response.code

                    if (response.isSuccessful) {
                        val responseBodyString = response.body?.string() ?: ""
                        if (responseBodyString.isNotBlank()) {
                            return@withContext parseGeminiResponse(responseBodyString)
                        }
                    } else {
                        val errBody = response.body?.string() ?: ""
                        Log.w(TAG, "Model $model returned code $responseCode: $errBody")
                        if (responseCode == 503 || responseCode == 429) {
                            // Model experiencing temporary high demand, wait briefly before trying next candidate
                            delay(500)
                            continue
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Attempt with model $model encountered network issue: ${e.message}")
                }
            }

            // Fallback seamlessly to smart local heuristic analysis if all remote endpoints are busy
            Log.w(TAG, "All models temporarily busy or unavailable, using smart local heuristic analysis.")
            performSmartHeuristicAnalysis(bitmap, isVideo, fileName)
        } catch (e: Exception) {
            Log.w(TAG, "Error during media analysis, falling back to local heuristic analysis: ${e.message}")
            performSmartHeuristicAnalysis(bitmap, isVideo, fileName)
        }
    }

    private fun buildAnalysisPrompt(isVideo: Boolean, fileName: String): String {
        val mediaType = if (isVideo) "video (khung hình trích xuất từ video)" else "hình ảnh"
        return """
            Bạn là một chuyên gia nhiếp ảnh và giám tuyển hình ảnh/video nghệ thuật chuyên nghiệp.
            Hãy phân tích kĩ lưỡng $mediaType (tên tệp: $fileName) dựa trên các tiêu chí:
            1. Độ nét và chi tiết (sharpness, blur, noise).
            2. Ánh sáng và độ phơi sáng (lighting, contrast, shadows, highlights).
            3. Bố cục và góc chụp (composition, rule of thirds, framing).
            4. Màu sắc và độ thẩm mỹ tổng thể (vibrancy, harmony).
            5. Ý nghĩa khoảnh khắc và độ thích hợp để chia sẻ lên mạng xã hội (Zalo, Messenger, Facebook).

            Trả về kết quả ĐÚNG định dạng JSON với schema sau (không thêm markdown ngoài JSON):
            {
              "score": <số nguyên từ 0 đến 100, phản ánh chất lượng tổng thể>,
              "verdict": "<chuỗi: 'Tuyệt phẩm' (nếu score >= 88), 'Chất lượng cao' (nếu score >= 75), 'Rất tốt' (nếu score >= 60), 'Trung bình' (nếu score >= 45), hoặc 'Cần cải thiện'>",
              "isRecommended": <boolean: true nếu score >= 70, false nếu ngược lại>,
              "sharpnessScore": <số nguyên từ 1 đến 10>,
              "lightingScore": <số nguyên từ 1 đến 10>,
              "compositionScore": <số nguyên từ 1 đến 10>,
              "colorScore": <số nguyên từ 1 đến 10>,
              "highlights": [
                "<ưu điểm 1 ngắn gọn bằng tiếng Việt>",
                "<ưu điểm 2 ngắn gọn bằng tiếng Việt>",
                "<ưu điểm 3 ngắn gọn bằng tiếng Việt>"
              ],
              "critique": "<đoạn nhận xét chuyên sâu bằng tiếng Việt về những chi tiết đẹp, ưu nhược điểm của ảnh/video>",
              "suggestedCaption": "<caption gợi ý hấp dẫn bằng tiếng Việt kèm emoji và hashtag để người dùng chia sẻ lên Zalo, Messenger, Facebook>"
            }
        """.trimIndent()
    }

    private fun parseGeminiResponse(rawJson: String): MediaAnalysis {
        val root = JSONObject(rawJson)
        val candidates = root.optJSONArray("candidates")
        val candidate = candidates?.optJSONObject(0)
        val content = candidate?.optJSONObject("content")
        val parts = content?.optJSONArray("parts")
        val text = parts?.optJSONObject(0)?.optString("text") ?: ""

        val cleanedJson = text.trim()
            .removePrefix("```json")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()

        val json = JSONObject(cleanedJson)
        val score = json.optInt("score", 75).coerceIn(0, 100)
        val verdict = json.optString("verdict", if (score >= 75) "Chất lượng cao" else "Rất tốt")
        val isRecommended = json.optBoolean("isRecommended", score >= 70)
        val sharpness = json.optInt("sharpnessScore", 8).coerceIn(1, 10)
        val lighting = json.optInt("lightingScore", 8).coerceIn(1, 10)
        val composition = json.optInt("compositionScore", 8).coerceIn(1, 10)
        val color = json.optInt("colorScore", 8).coerceIn(1, 10)

        val highlightsList = mutableListOf<String>()
        val highlightsArray = json.optJSONArray("highlights")
        if (highlightsArray != null) {
            for (i in 0 until highlightsArray.length()) {
                highlightsList.add(highlightsArray.optString(i))
            }
        }
        if (highlightsList.isEmpty()) {
            highlightsList.add("Độ chi tiết và màu sắc cân bằng tốt")
            highlightsList.add("Góc nhìn tự nhiên, bắt trọn khoảnh khắc")
        }

        val critique = json.optString("critique", "Hình ảnh có chất lượng chi tiết tốt, ánh sáng hài hòa và rất phù hợp để lưu giữ hoặc chia sẻ.")
        val suggestedCaption = json.optString("suggestedCaption", "Khoảnh khắc tuyệt vời hôm nay! ✨📸 #BeautifulMoments #Photography")

        return MediaAnalysis(
            score = score,
            verdict = verdict,
            isRecommended = isRecommended,
            sharpnessScore = sharpness,
            lightingScore = lighting,
            compositionScore = composition,
            colorScore = color,
            highlights = highlightsList,
            critique = critique,
            suggestedCaption = suggestedCaption
        )
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        val outputStream = ByteArrayOutputStream()
        // Resize if too big to optimize speed and network bandwidth
        val maxDim = 800
        val width = bitmap.width
        val height = bitmap.height
        val scaledBitmap = if (width > maxDim || height > maxDim) {
            val scale = maxDim.toFloat() / maxOf(width, height)
            val newW = (width * scale).roundToInt()
            val newH = (height * scale).roundToInt()
            Bitmap.createScaledBitmap(bitmap, newW, newH, true)
        } else {
            bitmap
        }
        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
        return Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
    }

    /**
     * Smart local heuristic analysis that inspects bitmap resolution, brightness,
     * color variance, and contrast to compute realistic, reproducible quality scores.
     */
    private fun performSmartHeuristicAnalysis(
        bitmap: Bitmap,
        isVideo: Boolean,
        fileName: String
    ): MediaAnalysis {
        val sampleW = minOf(100, bitmap.width)
        val sampleH = minOf(100, bitmap.height)
        val scaled = Bitmap.createScaledBitmap(bitmap, sampleW, sampleH, false)

        var totalLum = 0.0
        var totalSqDiff = 0.0
        val lums = DoubleArray(sampleW * sampleH)

        var idx = 0
        for (y in 0 until sampleH) {
            for (x in 0 until sampleW) {
                val pixel = scaled.getPixel(x, y)
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF
                val lum = 0.299 * r + 0.587 * g + 0.114 * b
                lums[idx++] = lum
                totalLum += lum
            }
        }
        val meanLum = totalLum / (sampleW * sampleH)
        for (lum in lums) {
            val diff = lum - meanLum
            totalSqDiff += diff * diff
        }
        val stdDev = kotlin.math.sqrt(totalSqDiff / (sampleW * sampleH))

        // Lighting score: optimal mean luminance is between 100 and 175
        val lightingScore = (10.0 - (kotlin.math.abs(meanLum - 130.0) / 130.0) * 5.0)
            .roundToInt().coerceIn(4, 10)

        // Contrast / Sharpness estimate based on standard deviation
        val sharpnessScore = ((stdDev / 70.0) * 8.0 + 2.0).roundToInt().coerceIn(5, 10)
        val compositionScore = ((sharpnessScore * 0.5 + lightingScore * 0.5)).roundToInt().coerceIn(6, 10)
        val colorScore = ((lightingScore + sharpnessScore) / 2).coerceIn(5, 10)

        val totalScore = ((sharpnessScore * 3.5) + (lightingScore * 3.0) + (compositionScore * 2.0) + (colorScore * 1.5))
            .roundToInt().coerceIn(45, 96)

        val verdict = when {
            totalScore >= 88 -> "Tuyệt phẩm"
            totalScore >= 75 -> "Chất lượng cao"
            totalScore >= 60 -> "Rất tốt"
            else -> "Trung bình"
        }

        val highlights = mutableListOf<String>()
        if (lightingScore >= 8) highlights.add("Ánh sáng hài hòa, độ phơi sáng chuẩn")
        if (sharpnessScore >= 8) highlights.add("Độ nét và chi tiết thể hiện rõ ràng")
        if (compositionScore >= 7) highlights.add("Bố cục cân đối, góc nhìn đẹp mắt")
        if (highlights.isEmpty()) {
            highlights.add("Khoảnh khắc tự nhiên, màu sắc tươi sáng")
        }

        val mediaLabel = if (isVideo) "Video" else "Bức ảnh"
        val critique = "$mediaLabel $fileName đạt điểm chất lượng $totalScore/100. " +
                "Độ sắc nét $sharpnessScore/10, ánh sáng $lightingScore/10 và độ tương phản tự nhiên, " +
                (if (totalScore >= 75) "rất xuất sắc và nổi bật để chia sẻ lên mạng xã hội." else "phù hợp để lưu trữ kỷ niệm.")

        val suggestedCaption = if (isVideo) {
            "Thước phim tuyệt vời bắt trọn khoảnh khắc đáng nhớ! 🎬✨ #Highlights #VideoOfTheDay #Memories"
        } else {
            "Góc ảnh tuyệt đẹp với ánh sáng và chi tiết hoàn hảo! 📸✨ #Photography #BestShot #PhotoOfTheDay"
        }

        return MediaAnalysis(
            score = totalScore,
            verdict = verdict,
            isRecommended = totalScore >= 70,
            sharpnessScore = sharpnessScore,
            lightingScore = lightingScore,
            compositionScore = compositionScore,
            colorScore = colorScore,
            highlights = highlights,
            critique = critique,
            suggestedCaption = suggestedCaption
        )
    }

    companion object {
        private const val TAG = "GeminiApiService"
    }
}
