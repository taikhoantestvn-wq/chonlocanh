package com.example.data.repository

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import com.example.data.model.MediaItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class MediaRepository(private val context: Context) {

    private val contentResolver: ContentResolver = context.contentResolver

    suspend fun loadDeviceMedia(): List<MediaItem> = withContext(Dispatchers.IO) {
        val items = mutableListOf<MediaItem>()

        // 1. Load Images
        try {
            val imageProjection = arrayOf(
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.MIME_TYPE,
                MediaStore.Images.Media.SIZE,
                MediaStore.Images.Media.DATE_ADDED,
                MediaStore.Images.Media.WIDTH,
                MediaStore.Images.Media.HEIGHT
            )

            val imageSortOrder = "${MediaStore.Images.Media.DATE_ADDED} DESC"

            contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                imageProjection,
                null,
                null,
                imageSortOrder
            )?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                val mimeColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE)
                val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
                val dateColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
                val widthColumn = cursor.getColumnIndex(MediaStore.Images.Media.WIDTH)
                val heightColumn = cursor.getColumnIndex(MediaStore.Images.Media.HEIGHT)

                var count = 0
                while (cursor.moveToNext() && count < 50) {
                    val id = cursor.getLong(idColumn)
                    val name = cursor.getString(nameColumn) ?: "IMG_$id.jpg"
                    val mime = cursor.getString(mimeColumn) ?: "image/jpeg"
                    val size = cursor.getLong(sizeColumn)
                    val dateAdded = cursor.getLong(dateColumn)
                    val width = if (widthColumn >= 0) cursor.getInt(widthColumn) else 0
                    val height = if (heightColumn >= 0) cursor.getInt(heightColumn) else 0

                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        id
                    )

                    items.add(
                        MediaItem(
                            id = id,
                            uri = contentUri,
                            name = name,
                            mimeType = mime,
                            isVideo = false,
                            size = size,
                            dateAdded = dateAdded,
                            width = width,
                            height = height
                        )
                    )
                    count++
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error querying images from MediaStore", e)
        }

        // 2. Load Videos
        try {
            val videoProjection = arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.MIME_TYPE,
                MediaStore.Video.Media.SIZE,
                MediaStore.Video.Media.DATE_ADDED,
                MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.WIDTH,
                MediaStore.Video.Media.HEIGHT
            )

            val videoSortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"

            contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                videoProjection,
                null,
                null,
                videoSortOrder
            )?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val mimeColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)
                val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val dateColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                val durationColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val widthColumn = cursor.getColumnIndex(MediaStore.Video.Media.WIDTH)
                val heightColumn = cursor.getColumnIndex(MediaStore.Video.Media.HEIGHT)

                var count = 0
                while (cursor.moveToNext() && count < 25) {
                    val id = cursor.getLong(idColumn)
                    val name = cursor.getString(nameColumn) ?: "VID_$id.mp4"
                    val mime = cursor.getString(mimeColumn) ?: "video/mp4"
                    val size = cursor.getLong(sizeColumn)
                    val dateAdded = cursor.getLong(dateColumn)
                    val duration = cursor.getLong(durationColumn)
                    val width = if (widthColumn >= 0) cursor.getInt(widthColumn) else 0
                    val height = if (heightColumn >= 0) cursor.getInt(heightColumn) else 0

                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        id
                    )

                    items.add(
                        MediaItem(
                            id = -id, // negative to distinguish from images
                            uri = contentUri,
                            name = name,
                            mimeType = mime,
                            isVideo = true,
                            durationMs = duration,
                            size = size,
                            dateAdded = dateAdded,
                            width = width,
                            height = height
                        )
                    )
                    count++
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error querying videos from MediaStore", e)
        }

        // Clean up legacy demo media folder if it exists
        try {
            val demoDir = File(context.cacheDir, "demo_media")
            if (demoDir.exists()) {
                demoDir.deleteRecursively()
            }
        } catch (ignored: Exception) {}

        items.sortedByDescending { it.dateAdded }
    }

    suspend fun createItemFromUri(uri: Uri): MediaItem = withContext(Dispatchers.IO) {
        var name = "Media_${System.currentTimeMillis()}"
        var mimeType = contentResolver.getType(uri) ?: "image/jpeg"
        var size = 0L

        try {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(MediaStore.MediaColumns.SIZE)
                val mimeIndex = cursor.getColumnIndex(MediaStore.MediaColumns.MIME_TYPE)

                if (cursor.moveToFirst()) {
                    if (nameIndex != -1) name = cursor.getString(nameIndex) ?: name
                    if (sizeIndex != -1) size = cursor.getLong(sizeIndex)
                    if (mimeIndex != -1) mimeType = cursor.getString(mimeIndex) ?: mimeType
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error inspecting uri metadata", e)
        }

        val isVideo = mimeType.startsWith("video/")
        MediaItem(
            id = System.currentTimeMillis(),
            uri = uri,
            name = name,
            mimeType = mimeType,
            isVideo = isVideo,
            size = size,
            dateAdded = System.currentTimeMillis() / 1000
        )
    }

    suspend fun loadBitmapForAnalysis(item: MediaItem): Bitmap? = withContext(Dispatchers.IO) {
        try {
            if (item.isVideo) {
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(context, item.uri)
                    // Get a frame at 1 second or first keyframe
                    val timeUs = 1_000_000L
                    var frame = retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    if (frame == null) {
                        frame = retriever.frameAtTime
                    }
                    return@withContext frame ?: generateFallbackBitmap(item.name, true)
                } finally {
                    try {
                        retriever.release()
                    } catch (ignored: Throwable) {}
                }
            } else {
                contentResolver.openInputStream(item.uri)?.use { stream ->
                    val options = BitmapFactory.Options().apply {
                        inJustDecodeBounds = true
                    }
                    BitmapFactory.decodeStream(stream, null, options)

                    // Calculate downsample factor
                    val maxDim = 1000
                    var inSampleSize = 1
                    while (options.outWidth / inSampleSize > maxDim || options.outHeight / inSampleSize > maxDim) {
                        inSampleSize *= 2
                    }

                    contentResolver.openInputStream(item.uri)?.use { secondStream ->
                        val decodeOptions = BitmapFactory.Options().apply {
                            this.inSampleSize = inSampleSize
                            inPreferredConfig = Bitmap.Config.RGB_565
                        }
                        return@withContext BitmapFactory.decodeStream(secondStream, null, decodeOptions)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error loading bitmap from uri ${item.uri}", e)
        }
        generateFallbackBitmap(item.name, item.isVideo)
    }

    private fun generateFallbackBitmap(title: String, isVideo: Boolean): Bitmap {
        val bitmap = Bitmap.createBitmap(600, 450, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(if (isVideo) Color.rgb(20, 25, 45) else Color.rgb(35, 30, 55))

        val paint = Paint().apply {
            color = Color.WHITE
            textSize = 34f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(if (isVideo) "🎬 $title" else "📷 $title", 300f, 225f, paint)
        return bitmap
    }

    companion object {
        private const val TAG = "MediaRepository"
    }
}
