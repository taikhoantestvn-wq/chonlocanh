package com.example.data.model

import android.net.Uri

data class MediaItem(
    val id: Long,
    val uri: Uri,
    val name: String,
    val mimeType: String,
    val isVideo: Boolean,
    val durationMs: Long = 0L,
    val size: Long = 0L,
    val dateAdded: Long = 0L,
    val width: Int = 0,
    val height: Int = 0,
    val analysis: MediaAnalysis? = null,
    val isAnalyzing: Boolean = false,
    val isSelected: Boolean = false
)

data class MediaAnalysis(
    val score: Int, // 0 - 100
    val verdict: String, // e.g., "Tuyệt phẩm", "Chất lượng cao", "Rất tốt", "Trung bình", "Kém"
    val isRecommended: Boolean, // true if score >= 70
    val sharpnessScore: Int, // 1 - 10
    val lightingScore: Int, // 1 - 10
    val compositionScore: Int, // 1 - 10
    val colorScore: Int, // 1 - 10
    val highlights: List<String>,
    val critique: String,
    val suggestedCaption: String
)

enum class FilterType {
    ALL,
    AI_RECOMMENDED,
    PHOTOS_ONLY,
    VIDEOS_ONLY
}

enum class SortType {
    AI_SCORE_DESC,
    DATE_DESC,
    DATE_ASC
}
