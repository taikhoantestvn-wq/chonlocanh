package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Chọn lọc ảnh AI", appName)
  }

  @Test
  fun `test api key manager persistence`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val apiKeyManager = com.example.data.repository.ApiKeyManager(context)

    // Initially blank
    apiKeyManager.clearCustomApiKey()
    assertEquals("", apiKeyManager.getCustomApiKey())
    assertEquals(false, apiKeyManager.hasCustomApiKey())

    // Save key
    apiKeyManager.saveCustomApiKey("AIzaSyTest123456")
    assertEquals("AIzaSyTest123456", apiKeyManager.getCustomApiKey())
    assertEquals(true, apiKeyManager.hasCustomApiKey())
    assertEquals("AIzaSyTest123456", apiKeyManager.getEffectiveApiKey())

    // Clear key
    apiKeyManager.clearCustomApiKey()
    assertEquals("", apiKeyManager.getCustomApiKey())
    assertEquals(false, apiKeyManager.hasCustomApiKey())
  }
}
